package com.ps5macro.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MacroAccessibilityService extends AccessibilityService {

    private static final long HOLD_CHUNK_MS = 40L;
    private static final long RELEASE_MS = 10L;
    private static final long QUICK_TAP_MS = 45L;

    private static WeakReference<MacroAccessibilityService> instanceRef = new WeakReference<>(null);

    private WindowManager windowManager;
    private Handler mainHandler;
    private MacroConfig config;

    private View floatingBarView;
    private WindowManager.LayoutParams barParams;
    private Button btnFloatLock;

    // Macro targets: M1, M2, M3
    private final TextView[] macroViews = new TextView[3];
    private final WindowManager.LayoutParams[] macroParams = new WindowManager.LayoutParams[3];

    // Normal game button targets: B1..B6
    private final TextView[] gameViews = new TextView[MacroConfig.MAX_GAME_BUTTONS];
    private final WindowManager.LayoutParams[] gameParams = new WindowManager.LayoutParams[MacroConfig.MAX_GAME_BUTTONS];

    private boolean isOverlayVisible = false;
    private boolean isLocked = false;
    private long lastMacroTime = 0L;

    // Multi-touch Hold/Tap Engine State (always accessed on mainHandler)
    private final Set<Integer> pressedButtons = new HashSet<>();
    private final Set<Integer> pendingTapButtons = new HashSet<>();
    private final Map<Integer, GestureDescription.StrokeDescription> activeStrokes = new HashMap<>();
    private final Map<Integer, float[]> activeStrokeCoords = new HashMap<>();
    private boolean gestureInFlight = false;
    private boolean macroRunning = false;

    public static MacroAccessibilityService getInstance() {
        return instanceRef.get();
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instanceRef = new WeakReference<>(this);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mainHandler = new Handler(Looper.getMainLooper());
        config = MacroConfig.load(this);
        // Disable key filtering while overlay is not locked so PS5 keys work in MainActivity & menus
        updateKeyFilterEnabled(false);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // No UI scraping needed.
    }

    @Override
    public void onInterrupt() {
        resetTouchEngine();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        hideOverlay();
        instanceRef.clear();
    }

    private void updateKeyFilterEnabled(boolean enabled) {
        try {
            AccessibilityServiceInfo info = getServiceInfo();
            if (info != null) {
                if (enabled) {
                    info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
                } else {
                    info.flags &= ~AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
                }
                setServiceInfo(info);
            }
        } catch (Throwable ignored) {
        }
    }

    public void reloadConfig() {
        config = MacroConfig.load(this);
        if (isOverlayVisible && mainHandler != null) {
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    rebuildTargetsKeepingBar();
                }
            });
        }
    }

    public void showOverlay() {
        if (windowManager == null) {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        }
        if (mainHandler == null) {
            mainHandler = new Handler(Looper.getMainLooper());
        }
        config = MacroConfig.load(this);

        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (isOverlayVisible) {
                    rebuildTargetsKeepingBar();
                    return;
                }
                try {
                    createFloatingBar();
                    createAllTargets();
                    isOverlayVisible = true;
                    setLocked(false);
                    Toast.makeText(MacroAccessibilityService.this,
                            "اسحب النقاط فوق أزرار اللعبة ثم اضغط (🔓 تحريك) للتفعيل",
                            Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    hideOverlay();
                    Toast.makeText(MacroAccessibilityService.this,
                            "تعذر إظهار النقاط: تأكد من تفعيل صلاحية الظهور فوق التطبيقات",
                            Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void hideOverlay() {
        if (mainHandler == null) {
            removeAllViewsInternal();
            return;
        }
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                removeAllViewsInternal();
            }
        });
    }

    private void resetTouchEngine() {
        pressedButtons.clear();
        pendingTapButtons.clear();
        activeStrokes.clear();
        activeStrokeCoords.clear();
        gestureInFlight = false;
        macroRunning = false;
    }

    private void removeAllViewsInternal() {
        resetTouchEngine();
        updateKeyFilterEnabled(false);

        if (windowManager != null) {
            if (floatingBarView != null) {
                try {
                    windowManager.removeView(floatingBarView);
                } catch (Exception ignored) {
                }
                floatingBarView = null;
            }
            removeTargetViewsOnly();
        }
        isOverlayVisible = false;
        isLocked = false;
    }

    private void removeTargetViewsOnly() {
        if (windowManager == null) {
            return;
        }
        for (int i = 0; i < macroViews.length; i++) {
            if (macroViews[i] != null) {
                try {
                    windowManager.removeView(macroViews[i]);
                } catch (Exception ignored) {
                }
                macroViews[i] = null;
                macroParams[i] = null;
            }
        }
        for (int i = 0; i < gameViews.length; i++) {
            if (gameViews[i] != null) {
                try {
                    windowManager.removeView(gameViews[i]);
                } catch (Exception ignored) {
                }
                gameViews[i] = null;
                gameParams[i] = null;
            }
        }
    }

    private void rebuildTargetsKeepingBar() {
        resetTouchEngine();
        removeTargetViewsOnly();
        createAllTargets();
        applyLockStateToTargets(isLocked);
    }

    private int getOverlayWindowType() {
        if (Settings.canDrawOverlays(this)) {
            return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
        return WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
    }

    private WindowManager.LayoutParams buildBaseParams(int width, int height, int flags) {
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                width,
                height,
                getOverlayWindowType(),
                flags,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return params;
    }

    private void createFloatingBar() {
        LayoutInflater inflater = LayoutInflater.from(this);
        floatingBarView = inflater.inflate(R.layout.layout_floating_bar, null);

        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;

        barParams = buildBaseParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                flags
        );
        barParams.x = 40;
        barParams.y = 100;

        TextView tvDragHandle = floatingBarView.findViewById(R.id.tvDragHandle);
        btnFloatLock = floatingBarView.findViewById(R.id.btnFloatLock);
        Button btnFloatRun = floatingBarView.findViewById(R.id.btnFloatRun);
        Button btnFloatClose = floatingBarView.findViewById(R.id.btnFloatClose);

        attachDragListener(tvDragHandle, floatingBarView, barParams, false, -1);

        btnFloatLock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setLocked(!isLocked);
            }
        });

        btnFloatRun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                executeMacro();
            }
        });

        btnFloatClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideOverlay();
            }
        });

        windowManager.addView(floatingBarView, barParams);
    }

    private void createAllTargets() {
        int macroSize = dpToPx(46);
        int gameSize = dpToPx(46);
        Rect bounds = getScreenBounds();

        int[] mXs = new int[]{config.x1, config.x2, config.x3};
        int[] mYs = new int[]{config.y1, config.y2, config.y3};
        int[] mBg = new int[]{R.drawable.bg_target_1, R.drawable.bg_target_2, R.drawable.bg_target_3};

        for (int i = 0; i < config.buttonCount; i++) {
            addCircleTarget(true, i, "M" + (i + 1), macroSize, bounds, mXs[i], mYs[i], mBg[i]);
        }

        for (int i = 0; i < MacroConfig.MAX_GAME_BUTTONS; i++) {
            if (config.gameBtnEnabled[i]) {
                String badge = KeyCodeHelper.getShortBadge(config.gameBtnKeyCode[i], i);
                addCircleTarget(false, i, badge, gameSize, bounds,
                        config.gameBtnX[i], config.gameBtnY[i], R.drawable.bg_game_btn);
            }
        }
    }

    private void addCircleTarget(boolean isMacro, int index, String label, int sizePx,
                                 Rect bounds, int centerX, int centerY, int bgRes) {
        int half = sizePx / 2;
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setGravity(Gravity.CENTER);
        tv.setTextColor(0xFFFFFFFF);
        tv.setTextSize(label.length() > 2 ? 12f : 15f);
        tv.setBackgroundResource(bgRes);

        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;

        WindowManager.LayoutParams params = buildBaseParams(sizePx, sizePx, flags);
        int safeCenterX = MacroConfig.clamp(centerX, half, Math.max(half + 1, bounds.width() - half));
        int safeCenterY = MacroConfig.clamp(centerY, half, Math.max(half + 1, bounds.height() - half));
        params.x = safeCenterX - half;
        params.y = safeCenterY - half;

        attachDragListener(tv, tv, params, isMacro, index);

        if (isMacro) {
            macroViews[index] = tv;
            macroParams[index] = params;
        } else {
            gameViews[index] = tv;
            gameParams[index] = params;
        }
        windowManager.addView(tv, params);
    }

    private void attachDragListener(View handle, final View rootView,
                                    final WindowManager.LayoutParams params,
                                    final boolean isMacro, final int index) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (index >= 0 && isLocked) {
                    return false;
                }
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        try {
                            windowManager.updateViewLayout(rootView, params);
                        } catch (Exception ignored) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (index >= 0) {
                            saveTargetPosition(isMacro, index, rootView);
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void saveTargetPosition(boolean isMacro, int index, View targetView) {
        int[] loc = new int[2];
        targetView.getLocationOnScreen(loc);
        int cx = loc[0] + (targetView.getWidth() / 2);
        int cy = loc[1] + (targetView.getHeight() / 2);

        if (isMacro) {
            if (index == 0) {
                config.x1 = cx;
                config.y1 = cy;
            } else if (index == 1) {
                config.x2 = cx;
                config.y2 = cy;
            } else if (index == 2) {
                config.x3 = cx;
                config.y3 = cy;
            }
        } else if (index >= 0 && index < MacroConfig.MAX_GAME_BUTTONS) {
            config.gameBtnX[index] = cx;
            config.gameBtnY[index] = cy;
        }
        config.save(this);
    }

    private void setLocked(boolean locked) {
        isLocked = locked;
        resetTouchEngine();
        updateKeyFilterEnabled(locked);

        if (btnFloatLock != null) {
            btnFloatLock.setText(locked ? "🔒 مفعّل" : "🔓 تحريك");
            btnFloatLock.setBackgroundResource(locked ? R.drawable.bg_button_green : R.drawable.bg_button_primary);
        }
        applyLockStateToTargets(locked);
    }

    private void applyLockStateToTargets(boolean locked) {
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (locked) {
            flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }
        float alpha = locked ? 0.36f : 0.92f;

        for (int i = 0; i < macroViews.length; i++) {
            if (macroViews[i] != null && macroParams[i] != null) {
                macroParams[i].flags = flags;
                macroViews[i].setAlpha(alpha);
                try {
                    windowManager.updateViewLayout(macroViews[i], macroParams[i]);
                } catch (Exception ignored) {
                }
            }
        }
        for (int i = 0; i < gameViews.length; i++) {
            if (gameViews[i] != null && gameParams[i] != null) {
                gameParams[i].flags = flags;
                gameViews[i].setAlpha(alpha);
                try {
                    windowManager.updateViewLayout(gameViews[i], gameParams[i]);
                } catch (Exception ignored) {
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Hardware Key Handling (Macro + Normal Game Buttons)
    // ------------------------------------------------------------------
    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        if (event == null || config == null || !isOverlayVisible || !isLocked) {
            return false;
        }

        final int keyCode = event.getKeyCode();
        final int action = event.getAction();
        final int repeatCount = event.getRepeatCount();

        // 1. Macro trigger button
        if (keyCode == config.triggerKeyCode) {
            if (action == KeyEvent.ACTION_DOWN && repeatCount == 0) {
                long now = SystemClock.uptimeMillis();
                if (now - lastMacroTime >= config.cooldownMs) {
                    lastMacroTime = now;
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            executeMacro();
                        }
                    });
                }
            }
            return true;
        }

        // 2. Normal game buttons (B1..B6)
        for (int i = 0; i < MacroConfig.MAX_GAME_BUTTONS; i++) {
            if (config.gameBtnEnabled[i] && config.gameBtnKeyCode[i] == keyCode) {
                final int btnIndex = i;
                if (action == KeyEvent.ACTION_DOWN) {
                    if (repeatCount == 0) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                onGameButtonDown(btnIndex);
                            }
                        });
                    }
                    return true;
                } else if (action == KeyEvent.ACTION_UP) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            onGameButtonUp(btnIndex);
                        }
                    });
                    return true;
                }
            }
        }

        return false;
    }

    private void onGameButtonDown(int btnIndex) {
        pressedButtons.add(btnIndex);
        pendingTapButtons.add(btnIndex);
        pulseView(gameViews[btnIndex], 0L);

        if (!macroRunning && !gestureInFlight) {
            pumpNextGesture();
        }
    }

    private void onGameButtonUp(int btnIndex) {
        pressedButtons.remove(btnIndex);
    }

    // ------------------------------------------------------------------
    // Multi-Touch Hold & Tap Engine
    // ------------------------------------------------------------------
    private void pumpNextGesture() {
        if (macroRunning || gestureInFlight || !isOverlayVisible) {
            return;
        }

        Rect bounds = getScreenBounds();
        float maxX = Math.max(10f, bounds.width() - 2f);
        float maxY = Math.max(10f, bounds.height() - 2f);

        GestureDescription.Builder builder = new GestureDescription.Builder();
        Map<Integer, GestureDescription.StrokeDescription> nextActive = new HashMap<>();
        Map<Integer, float[]> nextCoords = new HashMap<>();
        List<float[]> usedPoints = new ArrayList<>();
        int strokeCount = 0;

        // A. Continue or cleanly release already-active strokes (exact same endpoint!)
        for (Map.Entry<Integer, GestureDescription.StrokeDescription> entry : activeStrokes.entrySet()) {
            int btnIdx = entry.getKey();
            GestureDescription.StrokeDescription prevStroke = entry.getValue();
            float[] coord = activeStrokeCoords.get(btnIdx);
            if (coord == null) {
                coord = getLiveGameBtnCenter(btnIdx, maxX, maxY);
            }

            Path p = new Path();
            p.moveTo(coord[0], coord[1]);
            usedPoints.add(coord);

            if (pressedButtons.contains(btnIdx)) {
                GestureDescription.StrokeDescription cont = prevStroke.continueStroke(p, 0L, HOLD_CHUNK_MS, true);
                builder.addStroke(cont);
                nextActive.put(btnIdx, cont);
                nextCoords.put(btnIdx, coord);
            } else {
                GestureDescription.StrokeDescription endStroke = prevStroke.continueStroke(p, 0L, RELEASE_MS, false);
                builder.addStroke(endStroke);
            }
            strokeCount++;
        }

        // B. Add newly pressed or quick-tapped buttons
        Set<Integer> candidates = new HashSet<>(pressedButtons);
        candidates.addAll(pendingTapButtons);

        for (Integer btnIdx : candidates) {
            if (activeStrokes.containsKey(btnIdx)) {
                pendingTapButtons.remove(btnIdx);
                continue;
            }
            if (strokeCount >= 8) {
                break;
            }
            float[] coord = getLiveGameBtnCenter(btnIdx, maxX, maxY);
            coord = avoidCollision(coord, usedPoints, maxX, maxY);
            usedPoints.add(coord);

            Path p = new Path();
            p.moveTo(coord[0], coord[1]);
            pendingTapButtons.remove(btnIdx);

            if (pressedButtons.contains(btnIdx)) {
                GestureDescription.StrokeDescription fresh =
                        new GestureDescription.StrokeDescription(p, 0L, HOLD_CHUNK_MS, true);
                builder.addStroke(fresh);
                nextActive.put(btnIdx, fresh);
                nextCoords.put(btnIdx, coord);
            } else {
                // Ultra-fast tap already released before chunk boundary
                GestureDescription.StrokeDescription tap =
                        new GestureDescription.StrokeDescription(p, 0L, QUICK_TAP_MS, false);
                builder.addStroke(tap);
            }
            strokeCount++;
        }

        if (strokeCount == 0) {
            activeStrokes.clear();
            activeStrokeCoords.clear();
            return;
        }

        activeStrokes.clear();
        activeStrokes.putAll(nextActive);
        activeStrokeCoords.clear();
        activeStrokeCoords.putAll(nextCoords);

        try {
            boolean dispatched = dispatchGesture(builder.build(), new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gestureDescription) {
                    gestureInFlight = false;
                    if (!macroRunning) {
                        pumpNextGesture();
                    }
                }

                @Override
                public void onCancelled(GestureDescription gestureDescription) {
                    gestureInFlight = false;
                    activeStrokes.clear();
                    activeStrokeCoords.clear();
                    if (!macroRunning && (!pressedButtons.isEmpty() || !pendingTapButtons.isEmpty())) {
                        mainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                pumpNextGesture();
                            }
                        }, 15L);
                    }
                }
            }, null);

            if (dispatched) {
                gestureInFlight = true;
            } else {
                gestureInFlight = false;
                activeStrokes.clear();
                activeStrokeCoords.clear();
            }
        } catch (Exception e) {
            gestureInFlight = false;
            activeStrokes.clear();
            activeStrokeCoords.clear();
        }
    }

    private float[] avoidCollision(float[] point, List<float[]> used, float maxX, float maxY) {
        float x = point[0];
        float y = point[1];
        for (int tries = 0; tries < 6; tries++) {
            boolean clash = false;
            for (float[] u : used) {
                if (Math.hypot(x - u[0], y - u[1]) < 4.0) {
                    clash = true;
                    break;
                }
            }
            if (!clash) {
                break;
            }
            x = Math.min(maxX, x + 4f);
            y = Math.min(maxY, y + 2f);
        }
        return new float[]{x, y};
    }

    // ------------------------------------------------------------------
    // Exact-Timing 2-or-3 Button Macro Execution
    // ------------------------------------------------------------------
    public void executeMacro() {
        if (config == null) {
            config = MacroConfig.load(this);
        }

        macroRunning = true;
        gestureInFlight = false;
        activeStrokes.clear();
        activeStrokeCoords.clear();

        final boolean wasUnlocked = isOverlayVisible && !isLocked;
        if (wasUnlocked) {
            setAllTargetsTouchable(false);
        }

        Rect bounds = getScreenBounds();
        float maxX = Math.max(10f, bounds.width() - 2f);
        float maxY = Math.max(10f, bounds.height() - 2f);

        float[] p1 = getLiveMacroCenter(0, config.x1, config.y1, maxX, maxY);
        float[] p2 = getLiveMacroCenter(1, config.x2, config.y2, maxX, maxY);
        float[] p3 = getLiveMacroCenter(2, config.x3, config.y3, maxX, maxY);

        long dur1 = MacroConfig.clamp(config.hold1, 20, 2000);
        long dur2 = MacroConfig.clamp(config.hold2, 20, 2000);
        long dur3 = MacroConfig.clamp(config.hold3, 20, 2000);

        long start1 = 0L;
        long start2 = MacroConfig.clamp(config.delay1to2, 0, 5000);
        long start3 = start2 + MacroConfig.clamp(config.delay2to3, 0, 5000);

        if (start2 < start1 + dur1 && Math.hypot(p2[0] - p1[0], p2[1] - p1[1]) < 4.0) {
            p2[0] = Math.min(maxX, p2[0] + 4f);
        }
        if (config.buttonCount >= 3) {
            if (start3 < start1 + dur1 && Math.hypot(p3[0] - p1[0], p3[1] - p1[1]) < 4.0) {
                p3[0] = Math.min(maxX, p3[0] + 4f);
            }
            if (start3 < start2 + dur2 && Math.hypot(p3[0] - p2[0], p3[1] - p2[1]) < 4.0) {
                p3[1] = Math.min(maxY, p3[1] + 4f);
            }
        }

        try {
            GestureDescription.Builder builder = new GestureDescription.Builder();
            addTapStroke(builder, p1[0], p1[1], start1, dur1);
            addTapStroke(builder, p2[0], p2[1], start2, dur2);
            if (config.buttonCount >= 3) {
                addTapStroke(builder, p3[0], p3[1], start3, dur3);
            }

            pulseView(macroViews[0], start1);
            pulseView(macroViews[1], start2);
            if (config.buttonCount >= 3) {
                pulseView(macroViews[2], start3);
            }

            boolean dispatched = dispatchGesture(builder.build(), new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gestureDescription) {
                    finishMacro(wasUnlocked);
                }

                @Override
                public void onCancelled(GestureDescription gestureDescription) {
                    finishMacro(wasUnlocked);
                }
            }, null);

            if (!dispatched) {
                finishMacro(wasUnlocked);
            }
        } catch (Exception e) {
            finishMacro(wasUnlocked);
        }
    }

    private void finishMacro(boolean wasUnlocked) {
        macroRunning = false;
        if (wasUnlocked) {
            setAllTargetsTouchable(true);
        }
        if (!pressedButtons.isEmpty() || !pendingTapButtons.isEmpty()) {
            pumpNextGesture();
        }
    }

    private void addTapStroke(GestureDescription.Builder builder, float x, float y, long startTime, long duration) {
        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x + 0.5f, y + 0.5f);
        builder.addStroke(new GestureDescription.StrokeDescription(path, startTime, duration));
    }

    private float[] getLiveMacroCenter(int index, int fallbackX, int fallbackY, float maxX, float maxY) {
        return getViewCenterOrFallback(macroViews[index], fallbackX, fallbackY, maxX, maxY);
    }

    private float[] getLiveGameBtnCenter(int index, float maxX, float maxY) {
        return getViewCenterOrFallback(gameViews[index], config.gameBtnX[index], config.gameBtnY[index], maxX, maxY);
    }

    private float[] getViewCenterOrFallback(View v, int fallbackX, int fallbackY, float maxX, float maxY) {
        float x = fallbackX;
        float y = fallbackY;
        if (v != null && v.getWidth() > 0) {
            int[] loc = new int[2];
            v.getLocationOnScreen(loc);
            x = loc[0] + (v.getWidth() / 2f);
            y = loc[1] + (v.getHeight() / 2f);
        }
        x = Math.max(2f, Math.min(maxX, x));
        y = Math.max(2f, Math.min(maxY, y));
        return new float[]{x, y};
    }

    private void setAllTargetsTouchable(boolean touchable) {
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (!touchable) {
            flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }
        for (int i = 0; i < macroViews.length; i++) {
            if (macroViews[i] != null && macroParams[i] != null) {
                macroParams[i].flags = flags;
                try {
                    windowManager.updateViewLayout(macroViews[i], macroParams[i]);
                } catch (Exception ignored) {
                }
            }
        }
        for (int i = 0; i < gameViews.length; i++) {
            if (gameViews[i] != null && gameParams[i] != null) {
                gameParams[i].flags = flags;
                try {
                    windowManager.updateViewLayout(gameViews[i], gameParams[i]);
                } catch (Exception ignored) {
                }
            }
        }
    }

    private void pulseView(final View v, long delayMs) {
        if (v == null || mainHandler == null) {
            return;
        }
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                v.animate().scaleX(1.32f).scaleY(1.32f).setDuration(60).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(60).start();
                    }
                }).start();
            }
        }, delayMs);
    }

    @SuppressWarnings("deprecation")
    private Rect getScreenBounds() {
        if (windowManager != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                return windowManager.getCurrentWindowMetrics().getBounds();
            }
            DisplayMetrics dm = new DisplayMetrics();
            if (windowManager.getDefaultDisplay() != null) {
                windowManager.getDefaultDisplay().getRealMetrics(dm);
                return new Rect(0, 0, dm.widthPixels, dm.heightPixels);
            }
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        return new Rect(0, 0, dm.widthPixels, dm.heightPixels);
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
