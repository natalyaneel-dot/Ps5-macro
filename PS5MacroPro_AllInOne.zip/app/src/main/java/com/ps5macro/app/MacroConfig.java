package com.ps5macro.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.KeyEvent;

public class MacroConfig {

    public static final int MAX_GAME_BUTTONS = 6;

    private static final String PREFS_NAME = "ps5_macro_allinone_prefs";
    private static final String KEY_ACTIVE_SLOT = "active_slot";

    private static final int[] DEFAULT_GAME_KEYS = new int[]{
            KeyEvent.KEYCODE_BUTTON_A,      // Cross
            KeyEvent.KEYCODE_BUTTON_B,      // Circle
            KeyEvent.KEYCODE_BUTTON_X,      // Square
            KeyEvent.KEYCODE_BUTTON_Y,      // Triangle
            KeyEvent.KEYCODE_BUTTON_L1,     // L1
            KeyEvent.KEYCODE_BUTTON_R2      // R2
    };

    private static final boolean[] DEFAULT_GAME_ENABLED = new boolean[]{
            true,
            true,
            true,
            false,
            false,
            false
    };

    public int slotIndex = 0;
    public int triggerKeyCode = KeyEvent.KEYCODE_BUTTON_R1;
    public int buttonCount = 2;

    public int delay1to2 = 50;
    public int delay2to3 = 50;

    public int hold1 = 45;
    public int hold2 = 45;
    public int hold3 = 45;

    public int cooldownMs = 150;

    public int x1 = 320;
    public int y1 = 360;
    public int x2 = 480;
    public int y2 = 360;
    public int x3 = 640;
    public int y3 = 360;

    // 6 extra normal game buttons (shared across slots or saved cleanly)
    public boolean[] gameBtnEnabled = new boolean[MAX_GAME_BUTTONS];
    public int[] gameBtnKeyCode = new int[MAX_GAME_BUTTONS];
    public int[] gameBtnX = new int[MAX_GAME_BUTTONS];
    public int[] gameBtnY = new int[MAX_GAME_BUTTONS];

    public static int getActiveSlot(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return clamp(prefs.getInt(KEY_ACTIVE_SLOT, 0), 0, 2);
    }

    public static void setActiveSlot(Context context, int slot) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_ACTIVE_SLOT, clamp(slot, 0, 2)).apply();
    }

    public static MacroConfig load(Context context) {
        return loadSlot(context, getActiveSlot(context));
    }

    public static MacroConfig loadSlot(Context context, int slot) {
        int safeSlot = clamp(slot, 0, 2);
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String p = "slot_" + safeSlot + "_";

        MacroConfig cfg = new MacroConfig();
        cfg.slotIndex = safeSlot;
        cfg.triggerKeyCode = prefs.getInt(p + "trigger", KeyEvent.KEYCODE_BUTTON_R1);
        cfg.buttonCount = clamp(prefs.getInt(p + "count", 2), 2, 3);

        cfg.delay1to2 = clamp(prefs.getInt(p + "delay12", 50), 0, 5000);
        cfg.delay2to3 = clamp(prefs.getInt(p + "delay23", 50), 0, 5000);

        cfg.hold1 = clamp(prefs.getInt(p + "hold1", 45), 20, 2000);
        cfg.hold2 = clamp(prefs.getInt(p + "hold2", 45), 20, 2000);
        cfg.hold3 = clamp(prefs.getInt(p + "hold3", 45), 20, 2000);

        cfg.cooldownMs = clamp(prefs.getInt(p + "cooldown", 150), 50, 3000);

        cfg.x1 = prefs.getInt(p + "x1", 320);
        cfg.y1 = prefs.getInt(p + "y1", 360);
        cfg.x2 = prefs.getInt(p + "x2", 480);
        cfg.y2 = prefs.getInt(p + "y2", 360);
        cfg.x3 = prefs.getInt(p + "x3", 640);
        cfg.y3 = prefs.getInt(p + "y3", 360);

        for (int i = 0; i < MAX_GAME_BUTTONS; i++) {
            String gp = "gbtn_" + i + "_";
            cfg.gameBtnEnabled[i] = prefs.getBoolean(gp + "en", DEFAULT_GAME_ENABLED[i]);
            cfg.gameBtnKeyCode[i] = prefs.getInt(gp + "key", DEFAULT_GAME_KEYS[i]);
            cfg.gameBtnX[i] = prefs.getInt(gp + "x", 260 + (i % 3) * 150);
            cfg.gameBtnY[i] = prefs.getInt(gp + "y", 540 + (i / 3) * 140);
        }
        return cfg;
    }

    public void save(Context context) {
        int safeSlot = clamp(slotIndex, 0, 2);
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String p = "slot_" + safeSlot + "_";

        buttonCount = clamp(buttonCount, 2, 3);
        delay1to2 = clamp(delay1to2, 0, 5000);
        delay2to3 = clamp(delay2to3, 0, 5000);
        hold1 = clamp(hold1, 20, 2000);
        hold2 = clamp(hold2, 20, 2000);
        hold3 = clamp(hold3, 20, 2000);
        cooldownMs = clamp(cooldownMs, 50, 3000);

        SharedPreferences.Editor ed = prefs.edit()
                .putInt(KEY_ACTIVE_SLOT, safeSlot)
                .putInt(p + "trigger", triggerKeyCode)
                .putInt(p + "count", buttonCount)
                .putInt(p + "delay12", delay1to2)
                .putInt(p + "delay23", delay2to3)
                .putInt(p + "hold1", hold1)
                .putInt(p + "hold2", hold2)
                .putInt(p + "hold3", hold3)
                .putInt(p + "cooldown", cooldownMs)
                .putInt(p + "x1", x1)
                .putInt(p + "y1", y1)
                .putInt(p + "x2", x2)
                .putInt(p + "y2", y2)
                .putInt(p + "x3", x3)
                .putInt(p + "y3", y3);

        for (int i = 0; i < MAX_GAME_BUTTONS; i++) {
            String gp = "gbtn_" + i + "_";
            ed.putBoolean(gp + "en", gameBtnEnabled[i]);
            ed.putInt(gp + "key", gameBtnKeyCode[i]);
            ed.putInt(gp + "x", gameBtnX[i]);
            ed.putInt(gp + "y", gameBtnY[i]);
        }
        ed.apply();
    }

    public static int clamp(int value, int min, int max) {
        if (value < min) {
            return min;
        }
        if (value > max) {
            return max;
        }
        return value;
    }
}
