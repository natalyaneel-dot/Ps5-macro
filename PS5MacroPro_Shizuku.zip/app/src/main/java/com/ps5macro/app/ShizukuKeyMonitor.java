package com.ps5macro.app;

import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import rikka.shizuku.Shizuku;

public final class ShizukuKeyMonitor {

    public interface KeyListener {
        void onLinuxKeyDown(int linuxCode, String deviceName);
    }

    public interface StatusListener {
        void onMonitorStatus(boolean active, String message);
    }

    private static final ShizukuKeyMonitor INSTANCE = new ShizukuKeyMonitor();

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private volatile boolean running = false;
    private volatile Process currentProcess = null;
    private Thread readerThread = null;

    private volatile KeyListener uiKeyListener = null;
    private volatile KeyListener serviceKeyListener = null;
    private volatile StatusListener statusListener = null;
    private volatile String lastStatusMessage = "متوقف";

    private ShizukuKeyMonitor() {
    }

    public static ShizukuKeyMonitor getInstance() {
        return INSTANCE;
    }

    public static boolean isShizukuReady() {
        try {
            return Shizuku.pingBinder()
                    && !Shizuku.isPreV11()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    public void setUiKeyListener(KeyListener listener) {
        this.uiKeyListener = listener;
    }

    public void setServiceKeyListener(KeyListener listener) {
        this.serviceKeyListener = listener;
    }

    public void setStatusListener(StatusListener listener) {
        this.statusListener = listener;
    }

    public boolean isRunning() {
        return running;
    }

    public String getLastStatusMessage() {
        return lastStatusMessage;
    }

    public synchronized void ensureStarted() {
        if (running) {
            return;
        }
        if (!isShizukuReady()) {
            notifyStatus(false, "Shizuku غير جاهز أو بدون صلاحية");
            return;
        }

        running = true;
        readerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                runGetEventLoop();
            }
        }, "PS5Macro-ShizukuGetEvent");
        readerThread.start();
    }

    public synchronized void stopIfNoListeners() {
        if (uiKeyListener == null && serviceKeyListener == null) {
            stop();
        }
    }

    public synchronized void stop() {
        running = false;
        Process p = currentProcess;
        currentProcess = null;
        if (p != null) {
            try {
                p.destroy();
            } catch (Throwable ignored) {
            }
        }
        if (readerThread != null) {
            readerThread.interrupt();
            readerThread = null;
        }
        notifyStatus(false, "متوقف");
    }

    private Process createShizukuProcess(String[] cmd) throws Exception {
        Method method = Shizuku.class.getDeclaredMethod(
                "newProcess",
                String[].class,
                String[].class,
                String.class
        );
        method.setAccessible(true);
        return (Process) method.invoke(null, (Object) cmd, null, null);
    }

    private void runGetEventLoop() {
        Process process = null;
        try {
            process = createShizukuProcess(new String[]{"getevent"});
            currentProcess = process;
            notifyStatus(true, "يستمع ليد PS5 بصمت عبر Shizuku ✓");

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            Map<String, String> deviceNames = new HashMap<>();
            Set<String> ignoredDevices = new HashSet<>();
            Map<String, Integer> lastHatXMap = new HashMap<>();
            Map<String, Integer> lastHatYMap = new HashMap<>();

            String pendingDevicePath = null;
            String line;

            while (running && (line = reader.readLine()) != null) {
                String trimmed = line.trim();
                if (trimmed.isEmpty()) {
                    continue;
                }

                // Header lines printed by getevent at startup & hotplug
                if (trimmed.startsWith("add device")) {
                    int idx = trimmed.indexOf("/dev/input/");
                    if (idx >= 0) {
                        pendingDevicePath = trimmed.substring(idx).trim();
                    }
                    continue;
                }

                if (pendingDevicePath != null && trimmed.startsWith("name:")) {
                    String devName = extractQuotedName(trimmed);
                    deviceNames.put(pendingDevicePath, devName);
                    if (LinuxKeyHelper.isIgnoredDeviceName(devName)) {
                        ignoredDevices.add(pendingDevicePath);
                    }
                    pendingDevicePath = null;
                    continue;
                }

                // Event line format: /dev/input/eventX: 0001 0137 00000001
                String devPath = "";
                String payload = trimmed;
                int colonIdx = trimmed.indexOf(':');
                if (colonIdx > 0 && trimmed.startsWith("/dev/input/")) {
                    devPath = trimmed.substring(0, colonIdx).trim();
                    if (ignoredDevices.contains(devPath)) {
                        continue;
                    }
                    payload = trimmed.substring(colonIdx + 1).trim();
                }

                String[] parts = payload.split("\s+");
                if (parts.length < 3) {
                    continue;
                }

                int type;
                int code;
                int value;
                try {
                    type = (int) Long.parseLong(parts[0], 16);
                    code = (int) Long.parseLong(parts[1], 16);
                    value = (int) Long.parseLong(parts[2], 16);
                } catch (NumberFormatException ignored) {
                    continue;
                }

                String devName = deviceNames.containsKey(devPath) ? deviceNames.get(devPath) : devPath;

                if (type == 1) { // EV_KEY
                    if (value == 1 && !LinuxKeyHelper.isIgnoredSystemOrTouchKey(code)) {
                        dispatchKeyDown(code, devName);
                    }
                } else if (type == 3) { // EV_ABS (D-Pad HAT)
                    if (code == 16) { // ABS_HAT0X
                        Integer prevObj = lastHatXMap.get(devPath);
                        int prev = (prevObj == null) ? 0 : prevObj;
                        if (value == -1 && prev != -1) {
                            dispatchKeyDown(LinuxKeyHelper.CODE_DPAD_LEFT, devName);
                        } else if (value == 1 && prev != 1) {
                            dispatchKeyDown(LinuxKeyHelper.CODE_DPAD_RIGHT, devName);
                        }
                        lastHatXMap.put(devPath, value);
                    } else if (code == 17) { // ABS_HAT0Y
                        Integer prevObj = lastHatYMap.get(devPath);
                        int prev = (prevObj == null) ? 0 : prevObj;
                        if (value == -1 && prev != -1) {
                            dispatchKeyDown(LinuxKeyHelper.CODE_DPAD_UP, devName);
                        } else if (value == 1 && prev != 1) {
                            dispatchKeyDown(LinuxKeyHelper.CODE_DPAD_DOWN, devName);
                        }
                        lastHatYMap.put(devPath, value);
                    }
                }
            }
        } catch (Throwable t) {
            if (running) {
                notifyStatus(false, "خطأ في Shizuku: " + t.getMessage());
            }
        } finally {
            running = false;
            if (process != null) {
                try {
                    process.destroy();
                } catch (Throwable ignored) {
                }
            }
            if (currentProcess == process) {
                currentProcess = null;
            }
        }
    }

    private String extractQuotedName(String line) {
        int first = line.indexOf('"');
        int last = line.lastIndexOf('"');
        if (first >= 0 && last > first) {
            return line.substring(first + 1, last);
        }
        return line.replace("name:", "").trim();
    }

    private void dispatchKeyDown(final int linuxCode, final String deviceName) {
        final KeyListener serviceCb = serviceKeyListener;
        if (serviceCb != null) {
            serviceCb.onLinuxKeyDown(linuxCode, deviceName);
        }
        final KeyListener uiCb = uiKeyListener;
        if (uiCb != null) {
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    KeyListener activeUi = uiKeyListener;
                    if (activeUi != null) {
                        activeUi.onLinuxKeyDown(linuxCode, deviceName);
                    }
                }
            });
        }
    }

    private void notifyStatus(final boolean active, final String message) {
        lastStatusMessage = message;
        final StatusListener cb = statusListener;
        if (cb != null) {
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    StatusListener activeCb = statusListener;
                    if (activeCb != null) {
                        activeCb.onMonitorStatus(active, message);
                    }
                }
            });
        }
    }
}
