package com.ps5macro.app;

public final class LinuxKeyHelper {

    // Standard Linux evdev codes for PlayStation 5 DualSense
    public static final int CODE_BTN_SOUTH = 304;      // 0x130 Cross (or Square on older hid)
    public static final int CODE_BTN_EAST = 305;       // 0x131 Circle (or Cross on older hid)
    public static final int CODE_BTN_C = 306;          // 0x132
    public static final int CODE_BTN_NORTH = 307;      // 0x133 Triangle
    public static final int CODE_BTN_WEST = 308;       // 0x134 Square
    public static final int CODE_BTN_TL = 310;         // 0x136 L1
    public static final int CODE_BTN_TR = 311;         // 0x137 R1
    public static final int CODE_BTN_TL2 = 312;        // 0x138 L2
    public static final int CODE_BTN_TR2 = 313;        // 0x139 R2
    public static final int CODE_BTN_SELECT = 314;     // 0x13a Create / Share
    public static final int CODE_BTN_START = 315;      // 0x13b Options
    public static final int CODE_BTN_MODE = 316;       // 0x13c PS Button
    public static final int CODE_BTN_THUMBL = 317;     // 0x13d L3
    public static final int CODE_BTN_THUMBR = 318;     // 0x13e R3
    public static final int CODE_TOUCHPAD_CLICK = 272; // 0x110 BTN_LEFT

    // Synthetic codes for D-Pad HAT axes (ABS_HAT0X / ABS_HAT0Y)
    public static final int CODE_DPAD_LEFT = 10001;
    public static final int CODE_DPAD_RIGHT = 10002;
    public static final int CODE_DPAD_UP = 10003;
    public static final int CODE_DPAD_DOWN = 10004;

    public static final int[] COMMON_KEY_CODES = new int[]{
            CODE_BTN_THUMBR,
            CODE_BTN_THUMBL,
            CODE_BTN_TR,
            CODE_BTN_TL,
            CODE_BTN_TR2,
            CODE_BTN_TL2,
            CODE_BTN_SELECT,
            CODE_BTN_START,
            CODE_DPAD_UP,
            CODE_DPAD_DOWN,
            CODE_DPAD_LEFT,
            CODE_DPAD_RIGHT,
            CODE_BTN_SOUTH,
            CODE_BTN_EAST,
            CODE_BTN_WEST,
            CODE_BTN_NORTH,
            CODE_TOUCHPAD_CLICK
    };

    public static final String[] COMMON_KEY_LABELS = new String[]{
            "R3 (ضغط الأنالوج الأيمن)",
            "L3 (ضغط الأنالوج الأيسر)",
            "R1",
            "L1",
            "R2",
            "L2",
            "Create / Share",
            "Options",
            "سهم أعلى (D-Pad Up)",
            "سهم أسفل (D-Pad Down)",
            "سهم يسار (D-Pad Left)",
            "سهم يمين (D-Pad Right)",
            "✕ Cross (304)",
            "○ Circle (305)",
            "□ Square (308)",
            "△ Triangle (307)",
            "ضغطة لوحة اللمس (Touchpad)"
    };

    private LinuxKeyHelper() {
    }

    public static String getFriendlyName(int linuxCode) {
        for (int i = 0; i < COMMON_KEY_CODES.length; i++) {
            if (COMMON_KEY_CODES[i] == linuxCode) {
                return COMMON_KEY_LABELS[i] + " [" + linuxCode + "]";
            }
        }
        if (linuxCode == CODE_BTN_C) {
            return "زر اليد [306]";
        }
        if (linuxCode == CODE_BTN_MODE) {
            return "زر PS [316]";
        }
        return "زر اليد [" + linuxCode + "]";
    }

    public static int getSpinnerIndexForCode(int linuxCode) {
        for (int i = 0; i < COMMON_KEY_CODES.length; i++) {
            if (COMMON_KEY_CODES[i] == linuxCode) {
                return i;
            }
        }
        return -1;
    }

    public static boolean isIgnoredSystemOrTouchKey(int linuxCode) {
        // Ignore phone hardware keys (Power, Volume, Mute) and touchscreen BTN_TOUCH/BTN_TOOL_*
        return linuxCode == 113 // KEY_MUTE
                || linuxCode == 114 // KEY_VOLUMEDOWN
                || linuxCode == 115 // KEY_VOLUMEUP
                || linuxCode == 116 // KEY_POWER
                || linuxCode == 143 // KEY_WAKEUP
                || (linuxCode >= 325 && linuxCode <= 335); // BTN_TOOL_FINGER .. BTN_TOUCH .. BTN_TOOL_QUADTAP
    }

    public static boolean isIgnoredDeviceName(String name) {
        if (name == null) {
            return false;
        }
        String lower = name.toLowerCase();
        // Never ignore explicit gamepads/controllers
        if (lower.contains("controller")
                || lower.contains("dualsense")
                || lower.contains("dualshock")
                || lower.contains("sony")
                || lower.contains("gamepad")
                || lower.contains("joystick")) {
            return false;
        }
        return lower.contains("touchscreen")
                || lower.contains("touch_screen")
                || lower.contains("goodix")
                || lower.contains("focaltech")
                || lower.contains("synaptics")
                || lower.contains("novatek")
                || lower.contains("himax")
                || lower.contains("ilitek")
                || lower.contains("fts_ts")
                || lower.contains("sec_touch")
                || lower.contains("fingerprint")
                || lower.contains("uinput")
                || lower.contains("qpnp_pon")
                || lower.contains("gpio-keys");
    }
}
