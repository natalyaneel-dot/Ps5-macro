package com.ps5macro.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;

public class MacroAccessibilityService extends AccessibilityService implements ShizukuKeyMonitor.KeyListener {

    private static WeakReference<MacroAccessibilityService> instanceRef = new WeakReference<>(null);

    private WindowManager windowManager;
    private Handler mainHandler;
    private MacroConfig config;

    private View floatingBarView;
    private WindowManager.LayoutParams barParams;
    private Button btnFloatLock;

    private final TextView[] targetViews = new TextView[3];
    private final WindowManager.LayoutParams[] targetParams = new WindowManager.LayoutParams[3];

    private boolean isOverlayVisible = false;
    private boolean isLocked = false;
    private long lastTriggerTime = 0L;

    public static MacroAccessibilityService getInstance() {
        return instanceRef.get();
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instanceRef = new WeakReference<>(this);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mainHandler = new Handler(Looper.getMainLooper());
        config = MacroConfig.load(this);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Pure gesture dispatcher; never intercepts gamepad keys!
    }

    @Override
    public void onInterrupt() {
        // Nothing to interrupt.
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        hideOverlay();
        instanceRef.clear();
    }

    public void reloadConfig() {
        config = MacroConfig.load(this);
        if (isOverlayVisible && mainHandler != null) {
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    refreshTargetsForConfig();
                }
            });
        }
    }

    public boolean isOverlayVisible() {
        return isOverlayVisible;
    }

    public void showOverlay() {
        if (windowManager == null) {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        }
        if (mainHandler == null) {
            mainHandler = new Handler(Looper.getMainLooper());
        }
        config = MacroConfig.load(this);

        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                ShizukuKeyMonitor.getInstance().setServiceKeyListener(MacroAccessibilityService.this);
                ShizukuKeyMonitor.getInstance().ensureStarted();

                if (isOverlayVisible) {
                    refreshTargetsForConfig();
                    return;
                }
                try {
                    createFloatingBar();
                    createTargets();
                    isOverlayVisible = true;
                    setLocked(false);
                    Toast.makeText(MacroAccessibilityService.this,
                            "اسحب النقاط فوق أزرار اللعبة ثم اضغط (تحريك) لتفعيل الماكرو",
                            Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    hideOverlay();
                    Toast.makeText(MacroAccessibilityService.this,
                            "تعذر إظهار النقاط: تأكد من تفعيل صلاحية الظهور فوق التطبيقات",
                            Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void hideOverlay() {
        ShizukuKeyMonitor.getInstance().setServiceKeyListener(null);
        ShizukuKeyMonitor.getInstance().stopIfNoListeners();

        if (mainHandler == null) {
            removeAllViewsInternal();
            return;
        }
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                removeAllViewsInternal();
            }
        });
    }

    @Override
    public void onLinuxKeyDown(int linuxCode, String deviceName) {
        if (config == null || !isOverlayVisible || !isLocked) {
            return;
        }
        if (linuxCode == config.triggerLinuxCode) {
            long now = SystemClock.uptimeMillis();
            if (now - lastTriggerTime >= config.cooldownMs) {
                lastTriggerTime = now;
                if (mainHandler != null) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            executeMacro();
                        }
                    });
                }
            }
        }
    }

    private void removeAllViewsInternal() {
        if (windowManager != null) {
            if (floatingBarView != null) {
                try {
                    windowManager.removeView(floatingBarView);
                } catch (Exception ignored) {
                }
                floatingBarView = null;
            }
            for (int i = 0; i < targetViews.length; i++) {
                if (targetViews[i] != null) {
                    try {
                        windowManager.removeView(targetViews[i]);
                    } catch (Exception ignored) {
                    }
                    targetViews[i] = null;
                    targetParams[i] = null;
                }
            }
        }
        isOverlayVisible = false;
        isLocked = false;
    }

    private int getOverlayWindowType() {
        if (Settings.canDrawOverlays(this)) {
            return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
        return WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
    }

    private WindowManager.LayoutParams buildBaseParams(int width, int height, int flags) {
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                width,
                height,
                getOverlayWindowType(),
                flags,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return params;
    }

    private void createFloatingBar() {
        LayoutInflater inflater = LayoutInflater.from(this);
        floatingBarView = inflater.inflate(R.layout.layout_floating_bar, null);

        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;

        barParams = buildBaseParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                flags
        );
        barParams.x = 40;
        barParams.y = 120;

        TextView tvDragHandle = floatingBarView.findViewById(R.id.tvDragHandle);
        btnFloatLock = floatingBarView.findViewById(R.id.btnFloatLock);
        Button btnFloatRun = floatingBarView.findViewById(R.id.btnFloatRun);
        Button btnFloatClose = floatingBarView.findViewById(R.id.btnFloatClose);

        attachDragListener(tvDragHandle, floatingBarView, barParams, -1);

        btnFloatLock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setLocked(!isLocked);
            }
        });

        btnFloatRun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                executeMacro();
            }
        });

        btnFloatClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideOverlay();
            }
        });

        windowManager.addView(floatingBarView, barParams);
    }

    private void createTargets() {
        int sizePx = dpToPx(48);
        int half = sizePx / 2;
        Rect bounds = getScreenBounds();

        int[] xs = new int[]{config.x1, config.x2, config.x3};
        int[] ys = new int[]{config.y1, config.y2, config.y3};
        int[] bgRes = new int[]{R.drawable.bg_target_1, R.drawable.bg_target_2, R.drawable.bg_target_3};

        for (int i = 0; i < config.buttonCount; i++) {
            addSingleTarget(i, sizePx, half, bounds, xs[i], ys[i], bgRes[i]);
        }
    }

    private void addSingleTarget(int index, int sizePx, int half, Rect bounds, int centerX, int centerY, int bgRes) {
        TextView tv = new TextView(this);
        tv.setText(String.valueOf(index + 1));
        tv.setGravity(Gravity.CENTER);
        tv.setTextColor(0xFFFFFFFF);
        tv.setTextSize(17f);
        tv.setBackgroundResource(bgRes);

        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;

        WindowManager.LayoutParams params = buildBaseParams(sizePx, sizePx, flags);
        int safeCenterX = MacroConfig.clamp(centerX, half, Math.max(half + 1, bounds.width() - half));
        int safeCenterY = MacroConfig.clamp(centerY, half, Math.max(half + 1, bounds.height() - half));
        params.x = safeCenterX - half;
        params.y = safeCenterY - half;

        attachDragListener(tv, tv, params, index);

        targetViews[index] = tv;
        targetParams[index] = params;
        windowManager.addView(tv, params);
    }

    private void refreshTargetsForConfig() {
        if (!isOverlayVisible || windowManager == null) {
            return;
        }
        int sizePx = dpToPx(48);
        int half = sizePx / 2;
        Rect bounds = getScreenBounds();
        int[] xs = new int[]{config.x1, config.x2, config.x3};
        int[] ys = new int[]{config.y1, config.y2, config.y3};

        if (config.buttonCount == 3 && targetViews[2] == null) {
            addSingleTarget(2, sizePx, half, bounds, config.x3, config.y3, R.drawable.bg_target_3);
            setLocked(isLocked);
        } else if (config.buttonCount == 2 && targetViews[2] != null) {
            try {
                windowManager.removeView(targetViews[2]);
            } catch (Exception ignored) {
            }
            targetViews[2] = null;
            targetParams[2] = null;
        }

        for (int i = 0; i < config.buttonCount; i++) {
            if (targetViews[i] != null && targetParams[i] != null) {
                int safeCenterX = MacroConfig.clamp(xs[i], half, Math.max(half + 1, bounds.width() - half));
                int safeCenterY = MacroConfig.clamp(ys[i], half, Math.max(half + 1, bounds.height() - half));
                targetParams[i].x = safeCenterX - half;
                targetParams[i].y = safeCenterY - half;
                try {
                    windowManager.updateViewLayout(targetViews[i], targetParams[i]);
                } catch (Exception ignored) {
                }
            }
        }
    }

    private void attachDragListener(View handle, final View rootView, final WindowManager.LayoutParams params, final int targetIndex) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (targetIndex >= 0 && isLocked) {
                    return false;
                }
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        try {
                            windowManager.updateViewLayout(rootView, params);
                        } catch (Exception ignored) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (targetIndex >= 0) {
                            saveTargetPosition(targetIndex, rootView);
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void saveTargetPosition(int index, View targetView) {
        int[] loc = new int[2];
        targetView.getLocationOnScreen(loc);
        int cx = loc[0] + (targetView.getWidth() / 2);
        int cy = loc[1] + (targetView.getHeight() / 2);

        if (index == 0) {
            config.x1 = cx;
            config.y1 = cy;
        } else if (index == 1) {
            config.x2 = cx;
            config.y2 = cy;
        } else if (index == 2) {
            config.x3 = cx;
            config.y3 = cy;
        }
        config.save(this);
    }

    private void setLocked(boolean locked) {
        isLocked = locked;
        if (locked) {
            ShizukuKeyMonitor.getInstance().setServiceKeyListener(this);
            ShizukuKeyMonitor.getInstance().ensureStarted();
        }
        if (btnFloatLock != null) {
            btnFloatLock.setText(locked ? "🔒 مفعّل" : "🔓 تحريك");
            btnFloatLock.setBackgroundResource(locked ? R.drawable.bg_button_green : R.drawable.bg_button_primary);
        }

        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (locked) {
            flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }

        for (int i = 0; i < targetViews.length; i++) {
            if (targetViews[i] != null && targetParams[i] != null) {
                targetParams[i].flags = flags;
                targetViews[i].setAlpha(locked ? 0.38f : 0.92f);
                try {
                    windowManager.updateViewLayout(targetViews[i], targetParams[i]);
                } catch (Exception ignored) {
                }
            }
        }
    }

    public void executeMacro() {
        if (config == null) {
            config = MacroConfig.load(this);
        }

        final boolean wasUnlocked = isOverlayVisible && !isLocked;
        if (wasUnlocked) {
            setTargetsTouchable(false);
        }

        Rect bounds = getScreenBounds();
        float maxX = Math.max(10f, bounds.width() - 2f);
        float maxY = Math.max(10f, bounds.height() - 2f);

        float[] p1 = getLiveTargetCenter(0, config.x1, config.y1, maxX, maxY);
        float[] p2 = getLiveTargetCenter(1, config.x2, config.y2, maxX, maxY);
        float[] p3 = getLiveTargetCenter(2, config.x3, config.y3, maxX, maxY);

        long dur1 = MacroConfig.clamp(config.hold1, 20, 2000);
        long dur2 = MacroConfig.clamp(config.hold2, 20, 2000);
        long dur3 = MacroConfig.clamp(config.hold3, 20, 2000);

        long start1 = 0L;
        long start2 = MacroConfig.clamp(config.delay1to2, 0, 5000);
        long start3 = start2 + MacroConfig.clamp(config.delay2to3, 0, 5000);

        if (start2 < start1 + dur1 && Math.hypot(p2[0] - p1[0], p2[1] - p1[1]) < 4.0) {
            p2[0] = Math.min(maxX, p2[0] + 4f);
        }
        if (config.buttonCount >= 3) {
            if (start3 < start1 + dur1 && Math.hypot(p3[0] - p1[0], p3[1] - p1[1]) < 4.0) {
                p3[0] = Math.min(maxX, p3[0] + 4f);
            }
            if (start3 < start2 + dur2 && Math.hypot(p3[0] - p2[0], p3[1] - p2[1]) < 4.0) {
                p3[1] = Math.min(maxY, p3[1] + 4f);
            }
        }

        try {
            GestureDescription.Builder builder = new GestureDescription.Builder();
            addTapStroke(builder, p1[0], p1[1], start1, dur1);
            addTapStroke(builder, p2[0], p2[1], start2, dur2);
            if (config.buttonCount >= 3) {
                addTapStroke(builder, p3[0], p3[1], start3, dur3);
            }

            pulseTarget(0, start1);
            pulseTarget(1, start2);
            if (config.buttonCount >= 3) {
                pulseTarget(2, start3);
            }

            dispatchGesture(builder.build(), new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gestureDescription) {
                    if (wasUnlocked) {
                        setTargetsTouchable(true);
                    }
                }

                @Override
                public void onCancelled(GestureDescription gestureDescription) {
                    if (wasUnlocked) {
                        setTargetsTouchable(true);
                    }
                }
            }, null);
        } catch (Exception e) {
            if (wasUnlocked) {
                setTargetsTouchable(true);
            }
        }
    }

    private void addTapStroke(GestureDescription.Builder builder, float x, float y, long startTime, long duration) {
        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x + 0.5f, y + 0.5f);
        builder.addStroke(new GestureDescription.StrokeDescription(path, startTime, duration));
    }

    private float[] getLiveTargetCenter(int index, int fallbackX, int fallbackY, float maxX, float maxY) {
        float x = fallbackX;
        float y = fallbackY;
        if (targetViews[index] != null && targetViews[index].getWidth() > 0) {
            int[] loc = new int[2];
            targetViews[index].getLocationOnScreen(loc);
            x = loc[0] + (targetViews[index].getWidth() / 2f);
            y = loc[1] + (targetViews[index].getHeight() / 2f);
        }
        x = Math.max(2f, Math.min(maxX, x));
        y = Math.max(2f, Math.min(maxY, y));
        return new float[]{x, y};
    }

    private void setTargetsTouchable(boolean touchable) {
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (!touchable) {
            flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }
        for (int i = 0; i < targetViews.length; i++) {
            if (targetViews[i] != null && targetParams[i] != null) {
                targetParams[i].flags = flags;
                try {
                    windowManager.updateViewLayout(targetViews[i], targetParams[i]);
                } catch (Exception ignored) {
                }
            }
        }
    }

    private void pulseTarget(final int index, long delayMs) {
        if (targetViews[index] == null || mainHandler == null) {
            return;
        }
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                final TextView v = targetViews[index];
                if (v == null) {
                    return;
                }
                v.animate().scaleX(1.35f).scaleY(1.35f).setDuration(70).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(70).start();
                    }
                }).start();
            }
        }, delayMs);
    }

    @SuppressWarnings("deprecation")
    private Rect getScreenBounds() {
        if (windowManager != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                return windowManager.getCurrentWindowMetrics().getBounds();
            }
            DisplayMetrics dm = new DisplayMetrics();
            if (windowManager.getDefaultDisplay() != null) {
                windowManager.getDefaultDisplay().getRealMetrics(dm);
                return new Rect(0, 0, dm.widthPixels, dm.heightPixels);
            }
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        return new Rect(0, 0, dm.widthPixels, dm.heightPixels);
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
