package com.ps5macro.app;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import rikka.shizuku.Shizuku;

public class MainActivity extends AppCompatActivity implements
        ShizukuKeyMonitor.KeyListener,
        ShizukuKeyMonitor.StatusListener {

    private static final int REQ_CODE_SHIZUKU = 2026;

    private TextView tvShizukuStatus;
    private TextView tvAccessibilityStatus;
    private TextView tvOverlayStatus;
    private TextView tvCurrentTrigger;
    private TextView tvLastKeyPressed;

    private Button btnEnableShizuku;
    private Button btnSlot1;
    private Button btnSlot2;
    private Button btnSlot3;
    private Button btnBindPs5Key;

    private Spinner spinnerTriggerKey;

    private RadioGroup rgButtonCount;
    private RadioButton rbTwoButtons;
    private RadioButton rbThreeButtons;

    private EditText etDelay1to2;
    private EditText etDelay2to3;
    private EditText etHold1;
    private EditText etHold2;
    private EditText etHold3;
    private EditText etCooldown;

    private LinearLayout layoutDelay2to3;
    private LinearLayout layoutHold3;

    private MacroConfig config;
    private boolean isListeningForKey = false;
    private boolean ignoreNextSpinnerEvent = false;

    private final Shizuku.OnBinderReceivedListener binderReceivedListener = new Shizuku.OnBinderReceivedListener() {
        @Override
        public void onBinderReceived() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    updatePermissionStatus();
                    if (ShizukuKeyMonitor.isShizukuReady()) {
                        ShizukuKeyMonitor.getInstance().ensureStarted();
                    }
                }
            });
        }
    };

    private final Shizuku.OnBinderDeadListener binderDeadListener = new Shizuku.OnBinderDeadListener() {
        @Override
        public void onBinderDead() {
            ShizukuKeyMonitor.getInstance().stop();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    updatePermissionStatus();
                }
            });
        }
    };

    private final Shizuku.OnRequestPermissionResultListener permissionResultListener =
            new Shizuku.OnRequestPermissionResultListener() {
                @Override
                public void onRequestPermissionResult(int requestCode, int grantResult) {
                    if (requestCode == REQ_CODE_SHIZUKU) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updatePermissionStatus();
                                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                                    ShizukuKeyMonitor.getInstance().ensureStarted();
                                    Toast.makeText(MainActivity.this, "تم ربط Shizuku بنجاح ✓", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(MainActivity.this, "تم رفض صلاحية Shizuku", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bindViews();
        setupSpinner();
        setupListeners();

        config = MacroConfig.load(this);
        populateUiFromConfig();

        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener);
            Shizuku.addBinderDeadListener(binderDeadListener);
            Shizuku.addRequestPermissionResultListener(permissionResultListener);
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ShizukuKeyMonitor.getInstance().setUiKeyListener(this);
        ShizukuKeyMonitor.getInstance().setStatusListener(this);
        updatePermissionStatus();
        if (ShizukuKeyMonitor.isShizukuReady()) {
            ShizukuKeyMonitor.getInstance().ensureStarted();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        ShizukuKeyMonitor.getInstance().setUiKeyListener(null);
        ShizukuKeyMonitor.getInstance().setStatusListener(null);
        ShizukuKeyMonitor.getInstance().stopIfNoListeners();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener);
            Shizuku.removeBinderDeadListener(binderDeadListener);
            Shizuku.removeRequestPermissionResultListener(permissionResultListener);
        } catch (Throwable ignored) {
        }
    }

    private void bindViews() {
        tvShizukuStatus = findViewById(R.id.tvShizukuStatus);
        tvAccessibilityStatus = findViewById(R.id.tvAccessibilityStatus);
        tvOverlayStatus = findViewById(R.id.tvOverlayStatus);
        tvCurrentTrigger = findViewById(R.id.tvCurrentTrigger);
        tvLastKeyPressed = findViewById(R.id.tvLastKeyPressed);

        btnEnableShizuku = findViewById(R.id.btnEnableShizuku);
        btnSlot1 = findViewById(R.id.btnSlot1);
        btnSlot2 = findViewById(R.id.btnSlot2);
        btnSlot3 = findViewById(R.id.btnSlot3);
        btnBindPs5Key = findViewById(R.id.btnBindPs5Key);

        spinnerTriggerKey = findViewById(R.id.spinnerTriggerKey);

        rgButtonCount = findViewById(R.id.rgButtonCount);
        rbTwoButtons = findViewById(R.id.rbTwoButtons);
        rbThreeButtons = findViewById(R.id.rbThreeButtons);

        etDelay1to2 = findViewById(R.id.etDelay1to2);
        etDelay2to3 = findViewById(R.id.etDelay2to3);
        etHold1 = findViewById(R.id.etHold1);
        etHold2 = findViewById(R.id.etHold2);
        etHold3 = findViewById(R.id.etHold3);
        etCooldown = findViewById(R.id.etCooldown);

        layoutDelay2to3 = findViewById(R.id.layoutDelay2to3);
        layoutHold3 = findViewById(R.id.layoutHold3);
    }

    private void setupSpinner() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                R.layout.item_spinner,
                LinuxKeyHelper.COMMON_KEY_LABELS
        );
        adapter.setDropDownViewResource(R.layout.item_spinner);
        spinnerTriggerKey.setAdapter(adapter);
    }

    private void setupListeners() {
        Button btnEnableAccessibility = findViewById(R.id.btnEnableAccessibility);
        Button btnEnableOverlay = findViewById(R.id.btnEnableOverlay);
        Button btnSaveSettings = findViewById(R.id.btnSaveSettings);
        Button btnStartOverlay = findViewById(R.id.btnStartOverlay);
        Button btnStopOverlay = findViewById(R.id.btnStopOverlay);

        btnEnableShizuku.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleShizukuAction();
            }
        });

        btnEnableAccessibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });

        btnEnableOverlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(intent);
            }
        });

        btnSlot1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchSlot(0);
            }
        });
        btnSlot2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchSlot(1);
            }
        });
        btnSlot3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchSlot(2);
            }
        });

        btnBindPs5Key.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!ShizukuKeyMonitor.isShizukuReady()) {
                    Toast.makeText(MainActivity.this,
                            "يرجى تشغيل وربط Shizuku أولاً لتعيين زر يد PS5",
                            Toast.LENGTH_LONG).show();
                    return;
                }
                ShizukuKeyMonitor.getInstance().ensureStarted();
                isListeningForKey = !isListeningForKey;
                updateBindButtonUi();
            }
        });

        spinnerTriggerKey.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (ignoreNextSpinnerEvent) {
                    ignoreNextSpinnerEvent = false;
                    return;
                }
                if (position >= 0 && position < LinuxKeyHelper.COMMON_KEY_CODES.length) {
                    int selectedCode = LinuxKeyHelper.COMMON_KEY_CODES[position];
                    if (config.triggerLinuxCode != selectedCode) {
                        config.triggerLinuxCode = selectedCode;
                        tvCurrentTrigger.setText("الزر الحالي: " + LinuxKeyHelper.getFriendlyName(config.triggerLinuxCode));
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        rgButtonCount.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                boolean three = (checkedId == R.id.rbThreeButtons);
                layoutDelay2to3.setVisibility(three ? View.VISIBLE : View.GONE);
                layoutHold3.setVisibility(three ? View.VISIBLE : View.GONE);
            }
        });

        setupStepButton(R.id.btnDelay12Minus50, etDelay1to2, -50);
        setupStepButton(R.id.btnDelay12Minus10, etDelay1to2, -10);
        setupStepButton(R.id.btnDelay12Plus10, etDelay1to2, 10);
        setupStepButton(R.id.btnDelay12Plus50, etDelay1to2, 50);

        setupStepButton(R.id.btnDelay23Minus50, etDelay2to3, -50);
        setupStepButton(R.id.btnDelay23Minus10, etDelay2to3, -10);
        setupStepButton(R.id.btnDelay23Plus10, etDelay2to3, 10);
        setupStepButton(R.id.btnDelay23Plus50, etDelay2to3, 50);

        btnSaveSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUiToConfig();
                Toast.makeText(MainActivity.this, "تم حفظ إعدادات الماكرو بنجاح", Toast.LENGTH_SHORT).show();
            }
        });

        btnStartOverlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUiToConfig();
                if (!ShizukuKeyMonitor.isShizukuReady()) {
                    Toast.makeText(MainActivity.this,
                            "يرجى تشغيل وربط Shizuku أولاً حتى يعمل زر يد PS5",
                            Toast.LENGTH_LONG).show();
                    handleShizukuAction();
                    return;
                }
                MacroAccessibilityService service = MacroAccessibilityService.getInstance();
                if (service == null) {
                    Toast.makeText(MainActivity.this,
                            "يرجى تفعيل خدمة إمكانية الوصول (PS5 Macro Pro) أولاً",
                            Toast.LENGTH_LONG).show();
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    return;
                }
                service.showOverlay();
            }
        });

        btnStopOverlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MacroAccessibilityService service = MacroAccessibilityService.getInstance();
                if (service != null) {
                    service.hideOverlay();
                }
                Toast.makeText(MainActivity.this, "تم إخفاء النقاط وإيقاف الماكرو", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void handleShizukuAction() {
        try {
            if (!Shizuku.pingBinder()) {
                Intent launchIntent = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (launchIntent != null) {
                    Toast.makeText(this, "شغّل الخدمة داخل تطبيق Shizuku ثم ارجع هنا", Toast.LENGTH_LONG).show();
                    startActivity(launchIntent);
                } else {
                    Toast.makeText(this, "ثبّت تطبيق Shizuku من متجر Google Play وشغّله أولاً", Toast.LENGTH_LONG).show();
                }
                return;
            }
            if (Shizuku.isPreV11()) {
                Toast.makeText(this, "يرجى تحديث تطبيق Shizuku إلى آخر إصدار", Toast.LENGTH_LONG).show();
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(REQ_CODE_SHIZUKU);
            } else {
                ShizukuKeyMonitor.getInstance().ensureStarted();
                updatePermissionStatus();
                Toast.makeText(this, "Shizuku متصل ومستعد لاستقبال يد PS5 ✓", Toast.LENGTH_SHORT).show();
            }
        } catch (Throwable t) {
            Toast.makeText(this, "تعذر الاتصال بـ Shizuku: " + t.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onLinuxKeyDown(int linuxCode, String deviceName) {
        String friendly = LinuxKeyHelper.getFriendlyName(linuxCode);
        tvLastKeyPressed.setText("آخر زر تم ضغطه: " + friendly);

        if (isListeningForKey) {
            config.triggerLinuxCode = linuxCode;
            isListeningForKey = false;
            updateBindButtonUi();
            tvCurrentTrigger.setText("الزر الحالي: " + friendly);
            int idx = LinuxKeyHelper.getSpinnerIndexForCode(linuxCode);
            if (idx >= 0 && spinnerTriggerKey.getSelectedItemPosition() != idx) {
                ignoreNextSpinnerEvent = true;
                spinnerTriggerKey.setSelection(idx);
            }
            config.save(this);
            MacroAccessibilityService service = MacroAccessibilityService.getInstance();
            if (service != null) {
                service.reloadConfig();
            }
            Toast.makeText(this, "تم تعيين زر الماكرو: " + friendly, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onMonitorStatus(boolean active, String message) {
        updatePermissionStatus();
        if (!active && message != null && message.startsWith("خطأ")) {
            tvLastKeyPressed.setText(message);
        }
    }

    private void setupStepButton(int buttonId, final EditText target, final int delta) {
        Button btn = findViewById(buttonId);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int current = parseIntSafe(target.getText().toString(), 50);
                int next = MacroConfig.clamp(current + delta, 0, 5000);
                target.setText(String.valueOf(next));
            }
        });
    }

    private void switchSlot(int newSlot) {
        saveUiToConfig();
        MacroConfig.setActiveSlot(this, newSlot);
        config = MacroConfig.loadSlot(this, newSlot);
        populateUiFromConfig();
        MacroAccessibilityService service = MacroAccessibilityService.getInstance();
        if (service != null) {
            service.reloadConfig();
        }
    }

    private void populateUiFromConfig() {
        updateSlotButtonsUi(config.slotIndex);

        tvCurrentTrigger.setText("الزر الحالي: " + LinuxKeyHelper.getFriendlyName(config.triggerLinuxCode));
        int idx = LinuxKeyHelper.getSpinnerIndexForCode(config.triggerLinuxCode);
        if (idx >= 0 && spinnerTriggerKey.getSelectedItemPosition() != idx) {
            ignoreNextSpinnerEvent = true;
            spinnerTriggerKey.setSelection(idx);
        }

        boolean three = (config.buttonCount == 3);
        rbThreeButtons.setChecked(three);
        rbTwoButtons.setChecked(!three);
        layoutDelay2to3.setVisibility(three ? View.VISIBLE : View.GONE);
        layoutHold3.setVisibility(three ? View.VISIBLE : View.GONE);

        etDelay1to2.setText(String.valueOf(config.delay1to2));
        etDelay2to3.setText(String.valueOf(config.delay2to3));
        etHold1.setText(String.valueOf(config.hold1));
        etHold2.setText(String.valueOf(config.hold2));
        etHold3.setText(String.valueOf(config.hold3));
        etCooldown.setText(String.valueOf(config.cooldownMs));
    }

    private void saveUiToConfig() {
        config.buttonCount = rbThreeButtons.isChecked() ? 3 : 2;
        config.delay1to2 = MacroConfig.clamp(parseIntSafe(etDelay1to2.getText().toString(), 50), 0, 5000);
        config.delay2to3 = MacroConfig.clamp(parseIntSafe(etDelay2to3.getText().toString(), 50), 0, 5000);
        config.hold1 = MacroConfig.clamp(parseIntSafe(etHold1.getText().toString(), 45), 20, 2000);
        config.hold2 = MacroConfig.clamp(parseIntSafe(etHold2.getText().toString(), 45), 20, 2000);
        config.hold3 = MacroConfig.clamp(parseIntSafe(etHold3.getText().toString(), 45), 20, 2000);
        config.cooldownMs = MacroConfig.clamp(parseIntSafe(etCooldown.getText().toString(), 150), 50, 3000);

        config.save(this);
        populateUiFromConfig();

        MacroAccessibilityService service = MacroAccessibilityService.getInstance();
        if (service != null) {
            service.reloadConfig();
        }
    }

    private void updateSlotButtonsUi(int active) {
        btnSlot1.setBackgroundResource(active == 0 ? R.drawable.bg_button_primary : R.drawable.bg_button_secondary);
        btnSlot2.setBackgroundResource(active == 1 ? R.drawable.bg_button_primary : R.drawable.bg_button_secondary);
        btnSlot3.setBackgroundResource(active == 2 ? R.drawable.bg_button_primary : R.drawable.bg_button_secondary);
    }

    private void updateBindButtonUi() {
        if (isListeningForKey) {
            btnBindPs5Key.setText("بانتظار ضغطة زر من يد PS5 الآن... (اضغط للإلغاء)");
            btnBindPs5Key.setBackgroundResource(R.drawable.bg_button_green);
        } else {
            btnBindPs5Key.setText("اضغط هنا ثم اضغط أي زر في يد PS5 للتعيين");
            btnBindPs5Key.setBackgroundResource(R.drawable.bg_button_primary);
        }
    }

    private void updatePermissionStatus() {
        boolean shizukuAlive = false;
        boolean shizukuGranted = false;
        try {
            shizukuAlive = Shizuku.pingBinder() && !Shizuku.isPreV11();
            if (shizukuAlive) {
                shizukuGranted = (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED);
            }
        } catch (Throwable ignored) {
        }

        if (shizukuAlive && shizukuGranted) {
            boolean monitoring = ShizukuKeyMonitor.getInstance().isRunning();
            tvShizukuStatus.setText(monitoring ? "Shizuku: متصل ويستمع لليد ✓" : "Shizuku: متصل وجاهز ✓");
            tvShizukuStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_green));
            btnEnableShizuku.setText("متصل");
            btnEnableShizuku.setBackgroundResource(R.drawable.bg_button_green);
        } else if (shizukuAlive) {
            tvShizukuStatus.setText("Shizuku: شغّال (اضغط منح الصلاحية)");
            tvShizukuStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_orange));
            btnEnableShizuku.setText("صلاحية");
            btnEnableShizuku.setBackgroundResource(R.drawable.bg_button_primary);
        } else {
            tvShizukuStatus.setText("Shizuku: غير شغّال ✕");
            tvShizukuStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_red));
            btnEnableShizuku.setText("فتح");
            btnEnableShizuku.setBackgroundResource(R.drawable.bg_button_primary);
        }

        boolean accEnabled = isAccessibilityServiceEnabled();
        if (accEnabled) {
            tvAccessibilityStatus.setText("خدمة إمكانية الوصول: مفعّلة ✓");
            tvAccessibilityStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_green));
        } else {
            tvAccessibilityStatus.setText("خدمة إمكانية الوصول: غير مفعّلة ✕");
            tvAccessibilityStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_red));
        }

        boolean overlayEnabled = Settings.canDrawOverlays(this);
        if (overlayEnabled) {
            tvOverlayStatus.setText("الظهور فوق التطبيقات: مفعّل ✓");
            tvOverlayStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_green));
        } else {
            tvOverlayStatus.setText("الظهور فوق التطبيقات: غير مفعّل (يُفضّل تفعيله)");
            tvOverlayStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_orange));
        }
    }

    private boolean isAccessibilityServiceEnabled() {
        if (MacroAccessibilityService.getInstance() != null) {
            return true;
        }
        String expected = getPackageName() + "/" + MacroAccessibilityService.class.getName();
        String expectedShort = getPackageName() + "/." + MacroAccessibilityService.class.getSimpleName();
        String enabled = Settings.Secure.getString(
                getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );
        if (TextUtils.isEmpty(enabled)) {
            return false;
        }
        return enabled.contains(expected) || enabled.contains(expectedShort);
    }

    private int parseIntSafe(String raw, int fallback) {
        if (raw == null || raw.trim().isEmpty()) {
            return fallback;
        }
        try {
            return Integer.parseInt(raw.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }
}
